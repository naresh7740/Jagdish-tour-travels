Jagdish Tour & Travels – Barmer
=================================

यह एक responsive static website है।

कैसे चलाएँ:
1. index.html पर डबल-क्लिक करके मोबाइल/कंप्यूटर ब्राउज़र में खोलें।
2. WhatsApp और Call Now बटन आपके दिए गए नंबर से जुड़े हैं।
3. Gallery में बाद में अपनी असली गाड़ियों/यात्राओं की तस्वीरें लगाई जा सकती हैं।

मुख्य जानकारी:
- 8239396673
- 9602361436
- Barmer, Rajasthan
- Round Trip Taxi
- Tour Packages
- Local Sightseeing
- Airport Pickup & Drop

नोट:
यह वेबसाइट फाइल के रूप में तैयार है। इसे इंटरनेट पर लाइव करने के लिए किसी hosting service पर index.html अपलोड करना होगा।
